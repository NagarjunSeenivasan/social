// Selecting the search input and product elements
const searchInput = document.querySelector('input[name="q"]');
const products = document.querySelectorAll('.showcase');

// Add an event listener for the search input
searchInput.addEventListener('input', function(event) {
  const searchQuery = event.target.value.toLowerCase();

  // Loop through all the products and hide/show based on the search query
  products.forEach(product => {
    const title = product.querySelector('.showcase-title').textContent.toLowerCase();

    // Check if the product title includes the search query
    if (title.includes(searchQuery)) {
      product.style.display = 'block';
    } else {
      product.style.display = 'none';
    }
  });
});
